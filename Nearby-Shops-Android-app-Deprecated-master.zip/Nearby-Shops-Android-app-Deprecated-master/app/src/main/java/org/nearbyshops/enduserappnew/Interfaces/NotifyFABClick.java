package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 22/9/16.
 */

public interface NotifyFABClick {
//    void detachSelectedClick();
//    void changeParentForSelected();
    void addItem();
//    void addfromGlobalItem();
//    void addItemCategory();
//    void addfromGlobalItemCat();
    void removeSelectedFromShop();
    void addSelectedToShop();
}

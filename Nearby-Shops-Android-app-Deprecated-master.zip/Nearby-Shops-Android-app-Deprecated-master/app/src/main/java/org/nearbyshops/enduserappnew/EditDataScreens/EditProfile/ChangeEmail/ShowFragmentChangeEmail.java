package org.nearbyshops.enduserappnew.EditDataScreens.EditProfile.ChangeEmail;

/**
 * Created by sumeet on 28/6/17.
 */

public interface ShowFragmentChangeEmail {

    void showVerifyEmail();

    void showResultSuccess();
}

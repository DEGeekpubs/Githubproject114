package org.nearbyshops.enduserappnew.ShopReview.Interfaces;

/**
 * Created by sumeet on 23/10/16.
 */

public interface NotifyLoginByAdapter {

    void NotifyLoginAdapter();
}

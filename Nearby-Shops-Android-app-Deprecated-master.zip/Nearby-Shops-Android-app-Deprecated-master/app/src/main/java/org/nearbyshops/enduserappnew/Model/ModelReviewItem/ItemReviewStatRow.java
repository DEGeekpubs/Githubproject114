package org.nearbyshops.enduserappnew.Model.ModelReviewItem;

/**
 * Created by sumeet on 17/10/16.
 */
public class ItemReviewStatRow {

    private Integer rating;
    private Integer reviews_count;

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public Integer getReviews_count() {
        return reviews_count;
    }

    public void setReviews_count(Integer reviews_count) {
        this.reviews_count = reviews_count;
    }
}

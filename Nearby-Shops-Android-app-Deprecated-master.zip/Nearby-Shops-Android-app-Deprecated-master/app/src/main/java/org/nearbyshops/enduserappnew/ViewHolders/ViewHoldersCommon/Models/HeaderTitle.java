package org.nearbyshops.enduserappnew.ViewHolders.ViewHoldersCommon.Models;

/**
 * Created by sumeet on 4/12/16.
 */

public class HeaderTitle {

    public HeaderTitle(String heading) {
        this.heading = heading;
    }


    public HeaderTitle() {
    }

    private String heading;

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }
}

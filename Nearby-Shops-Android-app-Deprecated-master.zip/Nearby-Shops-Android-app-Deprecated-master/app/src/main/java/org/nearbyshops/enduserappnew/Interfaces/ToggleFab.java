package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 14/9/16.
 */

public interface ToggleFab {
    void showFab();
    void hideFab();
}

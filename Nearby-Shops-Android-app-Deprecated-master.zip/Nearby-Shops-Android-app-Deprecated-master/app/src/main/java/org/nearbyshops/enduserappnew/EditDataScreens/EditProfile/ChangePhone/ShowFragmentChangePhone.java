package org.nearbyshops.enduserappnew.EditDataScreens.EditProfile.ChangePhone;

/**
 * Created by sumeet on 28/6/17.
 */


public interface ShowFragmentChangePhone {


    void showVerifyPhone();

    void showResultSuccess();
}

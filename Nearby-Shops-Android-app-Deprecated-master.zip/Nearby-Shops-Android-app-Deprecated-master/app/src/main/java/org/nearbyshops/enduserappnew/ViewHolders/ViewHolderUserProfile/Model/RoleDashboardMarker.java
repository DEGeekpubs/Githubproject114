package org.nearbyshops.enduserappnew.ViewHolders.ViewHolderUserProfile.Model;

public class RoleDashboardMarker {
}

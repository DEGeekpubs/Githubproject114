package org.nearbyshops.enduserappnew.ViewHolders.ViewHoldersCommon.Models;

public class SignInMarker {
}

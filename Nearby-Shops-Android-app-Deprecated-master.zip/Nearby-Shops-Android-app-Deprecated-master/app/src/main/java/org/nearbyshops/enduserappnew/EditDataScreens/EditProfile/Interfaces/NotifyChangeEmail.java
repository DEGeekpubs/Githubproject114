package org.nearbyshops.enduserappnew.EditDataScreens.EditProfile.Interfaces;

/**
 * Created by sumeet on 15/4/17.
 */

public interface NotifyChangeEmail {
    void changeEmailClick();
}

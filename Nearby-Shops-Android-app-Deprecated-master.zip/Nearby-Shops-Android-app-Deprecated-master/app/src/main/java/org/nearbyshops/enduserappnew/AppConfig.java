package org.nearbyshops.enduserappnew;






public class AppConfig {

    public static final String MAPBOX_STYLE_URL = "https://api.maptiler.com/maps/bright/style.json?key=rgEe333l5zT9WTGlZXNR";
    public static final String styleURLBright = "https://api.maptiler.com/maps/bright/style.json?key=rgEe333l5zT9WTGlZXNR";
}

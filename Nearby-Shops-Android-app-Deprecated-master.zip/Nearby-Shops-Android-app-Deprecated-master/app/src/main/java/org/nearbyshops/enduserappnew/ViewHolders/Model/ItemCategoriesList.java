package org.nearbyshops.enduserappnew.ViewHolders.Model;

import org.nearbyshops.enduserappnew.Model.ItemCategory;

import java.util.List;



public class ItemCategoriesList {

    private List<ItemCategory> itemCategories;

    public List<ItemCategory> getItemCategories() {
        return itemCategories;
    }

    public void setItemCategories(List<ItemCategory> itemCategories) {
        this.itemCategories = itemCategories;
    }
}

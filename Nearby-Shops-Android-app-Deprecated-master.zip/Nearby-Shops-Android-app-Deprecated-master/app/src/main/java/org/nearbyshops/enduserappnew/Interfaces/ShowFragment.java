package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 23/4/17.
 */

public interface ShowFragment {

    void showLoginFragment();

    void showProfileFragment(boolean refreshFragment);

    void showOrdersFragment();

    void showCartFragment();

    void showShopsFragment();

    void showItemsFragment();
}

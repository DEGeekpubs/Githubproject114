package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 24/6/17.
 */

public interface OnFilterChanged {

    void taxiFiltersChanged();
}

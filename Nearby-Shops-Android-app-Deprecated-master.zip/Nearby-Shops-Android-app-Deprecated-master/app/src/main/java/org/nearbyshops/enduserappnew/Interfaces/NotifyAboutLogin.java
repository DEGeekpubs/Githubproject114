package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 2/7/17.
 */

public interface NotifyAboutLogin {

    void loginSuccess();
    void loggedOut();

}

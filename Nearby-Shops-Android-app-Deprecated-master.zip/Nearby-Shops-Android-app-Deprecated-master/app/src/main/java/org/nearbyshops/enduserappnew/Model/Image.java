package org.nearbyshops.enduserappnew.Model;

public class Image {
	
	String path;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}


}

package org.nearbyshops.enduserappnew.Login.SignUp.Interfaces;

/**
 * Created by sumeet on 28/6/17.
 */

public interface ShowFragmentForgotPassword {

    void showCheckResetCode();

    void showResetPassword();

    void showResultSuccess();
}

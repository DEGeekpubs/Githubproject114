package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 28/6/16.
 */

public interface NotifyTitleChangedNew {

    void NotifyTitleChanged(String title);
}

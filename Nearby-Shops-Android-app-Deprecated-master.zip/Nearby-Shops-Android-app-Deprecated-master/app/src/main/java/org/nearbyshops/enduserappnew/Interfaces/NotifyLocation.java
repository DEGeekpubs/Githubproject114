package org.nearbyshops.enduserappnew.Interfaces;

import android.location.Location;

/**
 * Created by sumeet on 12/1/17.
 */

public interface NotifyLocation {

    void fetchedLocation(Location location);
}

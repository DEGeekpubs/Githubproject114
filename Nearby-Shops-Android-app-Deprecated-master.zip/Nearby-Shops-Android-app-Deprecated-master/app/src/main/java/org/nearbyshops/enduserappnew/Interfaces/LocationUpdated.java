package org.nearbyshops.enduserappnew.Interfaces;

public interface LocationUpdated {
        void permissionGranted();
        void locationUpdated();
    }



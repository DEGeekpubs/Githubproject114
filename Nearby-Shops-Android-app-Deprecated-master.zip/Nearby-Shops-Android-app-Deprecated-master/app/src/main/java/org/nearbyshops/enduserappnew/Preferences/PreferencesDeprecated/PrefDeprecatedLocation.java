package org.nearbyshops.enduserappnew.Preferences.PreferencesDeprecated;

public class PrefDeprecatedLocation {



    // saving longitude

//    public static void saveProximity(Float proximity, Context context)
//    {
//
//        //Creating a shared preference
//
//        SharedPreferences sharedPref = context
//                .getSharedPreferences(
//                        context.getString(R.string.preference_file_name),
//                        MODE_PRIVATE
//                );
//
//
//        SharedPreferences.Editor prefsEditor = sharedPref.edit();
//
//        if(proximity == null)
//        {
//            prefsEditor.putFloat(KEY_PROXIMITY, -1);
//        }
//        else
//        {
//            prefsEditor.putFloat(KEY_PROXIMITY, proximity);
//        }
//
//        prefsEditor.apply();
//    }
//
//
//
//
//
//    public static Double getProximity(Context context)
//    {
//        SharedPreferences sharedPref = context.getSharedPreferences(context.getString(R.string.preference_file_name), MODE_PRIVATE);
//
//        Double proximity = (double) sharedPref.getFloat(KEY_PROXIMITY, -1);
//
//        if( proximity == -1)
//        {
//            return null;
//        }
//        else
//        {
//            return proximity;
//        }
//    }








    // saving longitude
//
//    public static void saveDeliveryRangeMax(Float rangeMax, Context context)
//    {
//
//        //Creating a shared preference
//
//        SharedPreferences sharedPref = context
//                .getSharedPreferences(
//                        context.getString(R.string.preference_file_name),
//                        MODE_PRIVATE
//                );
//
//
//        SharedPreferences.Editor prefsEditor = sharedPref.edit();
//
//        if(rangeMax == null)
//        {
//            prefsEditor.putFloat(KEY_DELIVERY_RANGE_MAX, -1);
//        }
//        else
//        {
//            prefsEditor.putFloat(KEY_DELIVERY_RANGE_MAX, rangeMax);
//        }
//
//        prefsEditor.apply();
//    }





//    public static Double getDeliveryRangeMax(Context context)
//    {
//        SharedPreferences sharedPref = context.getSharedPreferences(context.getString(R.string.preference_file_name), MODE_PRIVATE);
//
//        Double deliveryRangeMax = (double) sharedPref.getFloat(KEY_DELIVERY_RANGE_MAX, -1);
//
//        if( deliveryRangeMax == -1)
//        {
//            return null;
//        }
//        else
//        {
//            return deliveryRangeMax;
//        }
//    }


//
//
//    public static void saveDeliveryRangeMin(Float rangeMax, Context context)
//    {
//
//        //Creating a shared preference
//
//        SharedPreferences sharedPref = context
//                .getSharedPreferences(
//                        context.getString(R.string.preference_file_name),
//                        MODE_PRIVATE
//                );
//
//
//        SharedPreferences.Editor prefsEditor = sharedPref.edit();
//
//        if(rangeMax == null)
//        {
//            prefsEditor.putFloat(KEY_DELIVERY_RANGE_MIN, -1);
//        }
//        else
//        {
//            prefsEditor.putFloat(KEY_DELIVERY_RANGE_MIN, rangeMax);
//        }
//
//        prefsEditor.apply();
//    }
//
//
//    public static Double getDeliveryRangeMin(Context context)
//    {
//        SharedPreferences sharedPref = context.getSharedPreferences(
//                context.getString(R.string.preference_file_name),
//                MODE_PRIVATE);
//
//        Double deliveryRangeMax = (double) sharedPref.getFloat(KEY_DELIVERY_RANGE_MIN, -1);
//
//        if( deliveryRangeMax == -1)
//        {
//            return null;
//        }
//        else
//        {
//            return deliveryRangeMax;
//        }
//    }
}

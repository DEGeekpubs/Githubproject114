package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 18/8/16.
 */

public interface NotifyReviewUpdate {

    void notifyReviewUpdated();

    void notifyReviewDeleted();

    void notifyReviewSubmitted();

}

package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 29/9/16.
 */

public interface NotifySort {

    void notifySortChanged();
}

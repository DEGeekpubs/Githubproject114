package org.nearbyshops.enduserappnew.Login.SignUp.Interfaces;

/**
 * Created by sumeet on 28/6/17.
 */

public interface ShowFragmentSignUp {

    void showEmailPhone();

    void showVerifyEmail();

    void showEnterPassword();

    void showResultSuccess();
}

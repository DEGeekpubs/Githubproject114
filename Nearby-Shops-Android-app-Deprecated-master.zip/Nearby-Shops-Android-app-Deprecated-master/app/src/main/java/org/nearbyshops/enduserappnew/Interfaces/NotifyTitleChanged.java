package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 28/6/16.
 */

public interface NotifyTitleChanged {

    void NotifyTitleChanged(String title, int tabPosition);
}

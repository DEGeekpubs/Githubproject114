package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 13/11/16.
 */





public interface RefreshFragment {
    void refreshFragment();
}

package org.nearbyshops.enduserappnew.Interfaces;



public interface MarketSelected
{
    void marketSelected();
}


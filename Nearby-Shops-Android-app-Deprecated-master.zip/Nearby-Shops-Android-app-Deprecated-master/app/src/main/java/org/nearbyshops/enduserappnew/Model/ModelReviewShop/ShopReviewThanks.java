package org.nearbyshops.enduserappnew.Model.ModelReviewShop;


/**
 * Created by sumeet on 21/10/16.
 */

public class ShopReviewThanks{



    // instance Variables

    private int endUserID;
    private int shopReviewID;





    public int getEndUserID() {
        return endUserID;
    }

    public void setEndUserID(int endUserID) {
        this.endUserID = endUserID;
    }

    public int getShopReviewID() {
        return shopReviewID;
    }

    public void setShopReviewID(int shopReviewID) {
        this.shopReviewID = shopReviewID;
    }
}

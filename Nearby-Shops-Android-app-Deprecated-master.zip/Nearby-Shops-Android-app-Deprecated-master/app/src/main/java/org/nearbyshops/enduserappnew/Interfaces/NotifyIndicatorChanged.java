package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 22/9/16.
 */

public interface NotifyIndicatorChanged {

    void notifyItemIndicatorChanged(String header);
}

package org.nearbyshops.enduserappnew.Interfaces;

/**
 * Created by sumeet on 1/11/16.
 */

public interface NotifySearch {

    void search(String searchString);

    void endSearchMode();
}
